import React, { useEffect, useState } from "react";
import { MaterialReactTable } from "material-react-table";
import { Line } from "@ant-design/plots";
import Axios from "axios";
import { DatePicker } from "antd";
import dayjs from "dayjs";
import "./Tlf_1.scss";
import { useLocation, useNavigate } from "react-router-dom";
import localeData from "dayjs/plugin/localeData";
import ExportCSVButton from "../export-to-pdf/ExportCSVButton";
import ExportToPdfButton from "../export-to-pdf/ExportToPdfButton";
const Tlf_20 = (props) => {
  const [data, setData] = useState([]);
  const { state } = useLocation();
  const navigate = useNavigate();

  const [columns, setColumns] = useState([]);
  const [dataGrid, setDataGrid] = useState([]);

  const fromdate = props.fromdate;

  const getDate = () => {
    const getToday = new Date();
    var date = new Date(getToday),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    const fromdate = [date.getFullYear(), mnth, day].join("-");
  };

  const getData = () => {
    Axios.get(
      `http://${window.location.hostname}:3005/TLF_20_Combined_Graph`
    ).then((result) => {
      //BCU01
      const newData = result.data.recordsets.map((graph) => graph);
      setData(newData);
      console.log("graph1", newData);
    });
  };

  // const getGriddata = () => {
  //   Axios.get(
  //     `http://${window.location.hostname}:3005/TLF_20_Combined_Grid`
  //   ).then((result) => {
  //     const list = result.data.recordsets[0];

  //     if (list) {
  //       const firstObject = list[0] || {};
  //       const cols = [];
  //       for (const key in firstObject) {
  //         const col = {
  //           // styles: { col },
  //           title: key,
  //           dataIndex: key,
  //           header: key,

  //           accessorKey: key,
  //         };
  //         if (typeof firstObject[key] === "number") {
  //           col.filterVariant = "range";
  //           col.filterFn = "between";
  //           col.size = 80;
  //         }
  //         cols.push(col);
  //       }
  //       setColumns(cols);
  //       setDataGrid(list);
  //     }
  //   });
  // };

  useEffect(() => {
    getData();
    // getGriddata();
  }, [props.fromdate]);

  const config = (index) => {
    return {
      data: data[index],
      xField: "Time",
      yField: "AlarmType",
      // seriesField: "Source",
      stepType: "vh",
      xAxis: {
        label: {
          position: "middle",
          rotate: 120,
          offsetX: 55,
        },
        title: {
          text: "Time",
        },
      },
      yAxis: {
        title: {
          text: "Status",
        },
      },
    };
  };

  // const config2 = {
  //   data2,
  //   xField: "Time2",
  //   yField: "AlarmType",
  //   seriesField: "Source2",
  //   stepType: "vh",
  //   xAxis: {
  //     label: {
  //       position: "middle",
  //       rotate: 120,
  //       offsetX: 55,
  //     },
  //     title: {
  //       text: "Time",
  //     },
  //   },
  //   yAxis: {
  //     title: {
  //       text: "Status",
  //     },
  //   },
  // };

  // const config3 = {
  //   data3,
  //   xField: "Time3",
  //   yField: "AlarmType",
  //   seriesField: "Source3",
  //   stepType: "vh",
  //   xAxis: {
  //     label: {
  //       position: "middle",
  //       rotate: 120,
  //       offsetX: 55,
  //     },
  //     title: {
  //       text: "Time",
  //     },
  //   },
  //   yAxis: {
  //     title: {
  //       text: "Status",
  //     },
  //   },
  // };

  // const config4 = {
  //   data4,
  //   xField: "Time4",
  //   yField: "AlarmType",
  //   seriesField: "Source4",
  //   stepType: "vh",
  //   xAxis: {
  //     label: {
  //       position: "middle",
  //       rotate: 120,
  //       offsetX: 55,
  //     },
  //     title: {
  //       text: "Time4",
  //     },
  //   },
  //   yAxis: {
  //     title: {
  //       text: "Status4",
  //     },
  //   },
  // };

  // const config5 = {
  //   data5,
  //   xField: "Time5",
  //   yField: "AlarmType",
  //   seriesField: "Source5",
  //   stepType: "vh",
  //   xAxis: {
  //     label: {
  //       position: "middle",
  //       rotate: 120,
  //       offsetX: 55,
  //     },
  //     title: {
  //       text: "Time",
  //     },
  //   },
  //   yAxis: {
  //     title: {
  //       text: "Status",
  //     },
  //   },
  // };

  // const config6 = {
  //   data6,
  //   xField: "Time6",
  //   yField: "AlarmType",
  //   seriesField: "Source6",
  //   stepType: "vh",
  //   xAxis: {
  //     label: {
  //       position: "middle",
  //       rotate: 120,
  //       offsetX: 55,
  //     },
  //     title: {
  //       text: "Time6",
  //     },
  //   },
  //   yAxis: {
  //     title: {
  //       text: "Status6",
  //     },
  //   },
  // };

  return (
    <div className="Analytics">
      <div
        style={{
          backgroundColor: "black",
          color: "white",
          fontweight: "1rem",
          fontSize: "1.5rem",
        }}
      >
        <h3
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          {state.PageTitle}
        </h3>
      </div>

      <div  classname="row">
        {" "}
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        <div
          classname="col-sm-6"
          style={{
            float: "left",
            width: "47%",
            zIndex: "0",
            position: "relative",
          }}
        >
          <p
            style={{
              fontSize: "20px",
              backgroundColor: "black",
              color: "white",
            }}
          >
            <strong>BCU2 A</strong>
          </p>
          {data.map((graph, index) => (
            <div style={{ height: "500px" }} key={index}>
              {" "}
              <Line {...config(index)} />
            </div>
          ))}
        </div>
        <div
          classname="col-sm-6"
          style={{
            float: "right",
            width: "47%",
            zIndex: "0",
            position: "relative",
          }}
        >
          <p
            style={{
              fontSize: "20px",
              backgroundColor: "black",
              color: "white",
            }}
          >
            <strong>BCU2 B</strong>
          </p>
          {data.map((graph, index) => (
            <div style={{ height: "500px" }} key={index}>
              {" "}
              <Line {...config(index)} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
export default Tlf_20;
